import 'package:flutter/material.dart';

import 'core/constants/hesap_strings.dart';
import 'core/constants/hesap_theme.dart';

class HesapApp extends StatelessWidget {
  const HesapApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: HesapStrings.appTitle,
      theme: HesapTheme.themeData,
      home: Column(),
    );
  }
}