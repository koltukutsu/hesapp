import 'package:flutter/material.dart';

class HesapTheme {
  static final ThemeData themeData = ThemeData();
}