enum NavbarItem {
  restaurantEkran,
  siparisEkran
}