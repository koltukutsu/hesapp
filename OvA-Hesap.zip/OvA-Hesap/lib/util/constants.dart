/// Navigasyon Rotaları
const String ROUTE_BASE = '/';
const String ROUTE_MAIN = '/main';
const String ROUTE_SIGN_IN = '/sign_in';
const String ROUTE_SIGN_UP = '/sign_up';
const String ROUTE_QR_SCREEN = '/qr_screen';
const String ROUTE_RESTAURANTS = 'restaurants';
