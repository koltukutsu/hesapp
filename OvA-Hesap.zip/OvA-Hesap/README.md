# **Takım 24**
# hesap
QR Kod ile Ödeme Uygulaması

### Sprint ile ilgili bilgilere aşağıdaki linkten ulaşabilirsiniz
[Takım 24 Proje Yönetimi](https://github.com/koltukutsu/Takim24---BootcampScrumTemplate)

### Not
Uygulamamıza ait kodlar private olarak bu repoda paylaşılmaktadır. Proje yönetimi ile ilgili tüm gerekli bilgiler public olarak ayrı bir repoda paylaşılmıştır (yukarıdaki linkte).  
