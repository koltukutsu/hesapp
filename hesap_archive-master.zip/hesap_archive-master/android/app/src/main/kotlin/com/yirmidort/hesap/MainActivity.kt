package com.yirmidort.hesap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
