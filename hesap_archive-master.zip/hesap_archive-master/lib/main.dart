import 'package:flutter/material.dart';

import 'hesap_app.dart';

void main() {
  runApp(
    const HesapApp(),
  );
}
