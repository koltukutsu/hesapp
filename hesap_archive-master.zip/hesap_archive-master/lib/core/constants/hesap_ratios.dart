class HesapRatios {
  static const double shuffleButtonWidthRatio = 306 / 413; // 0.74
}
