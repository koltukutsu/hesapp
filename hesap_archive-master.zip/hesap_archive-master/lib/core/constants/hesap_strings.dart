class HesapStrings {
  static const String appTitle = "Hesap";
}
