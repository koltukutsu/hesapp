import 'package:flutter/material.dart';
import 'package:hesap/core/constants/hesap_colors.dart';

class HesapTheme {
  static final ThemeData themeData = ThemeData(
    primaryColor: HesapColors.primary,
  );
}
