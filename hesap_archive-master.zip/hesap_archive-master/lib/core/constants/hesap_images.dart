class HesapImages {
  //static const String appIcon = "assets/images/app_icon.png";
}
