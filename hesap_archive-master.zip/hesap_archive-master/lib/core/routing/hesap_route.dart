import 'package:flutter/material.dart';
import 'package:hesap/features/1_authentication/presentation/animated_splash_screen/animated_splash_screen.dart';
import 'package:hesap/features/1_authentication/presentation/giris_yap/giris_yap_screen.dart';
import 'package:hesap/features/1_authentication/presentation/name/name_screen.dart';
import 'package:hesap/features/1_authentication/presentation/on_boarding/on_boarding_screen.dart';
import 'package:hesap/features/1_authentication/presentation/uye_ol/uye_ol_ekran.dart';
import 'package:hesap/hesap_app.dart';

import '../../features/1_authentication/presentation/on_boarding/components/hesap_aydinlatma_metni.dart';

enum PageRouteTypes {
  // 1_authentication
  authAnimatedSplashScreen,
  authClarificationText,
  authOnBoarding,
  authWithoutRegister,
  authRegister,
  authLogin,
  // 2_observe_restaurants
  restaurantMain,
  // 3_take_table
  tableQrRead,
  tableTakeTable, // pop up screen
  tableCreditCard,
  // 4_order
  orderBasket,
  orderPayment,
  // common
  commonInternetControl, // actually it must be common
  commonProfile,
}
// how to use it
// Navigator.of(context).push(createPageRoute(
//                               pageRouteType: PageRouteTypes.fromMainToMarket));

Route createPageRoute({required PageRouteTypes pageRouteType}) {
  // 1 AUTH
  if (pageRouteType == PageRouteTypes.authAnimatedSplashScreen) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const HesapAnimatedSplashScreen(),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  } else if (pageRouteType == PageRouteTypes.authClarificationText) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const HesapAydinlatmaMetni(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  } else if (pageRouteType == PageRouteTypes.authOnBoarding) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const OnBoardingScreen(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  } else if (pageRouteType == PageRouteTypes.authWithoutRegister) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const NameScreen(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  } else if (pageRouteType == PageRouteTypes.authRegister) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const UyeOlEkran(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  } else if (pageRouteType == PageRouteTypes.authLogin) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const GirisYapEkran(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  }
  // 2 RESTAURANT
  else if (pageRouteType == PageRouteTypes.restaurantMain) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const HesapApp(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  }
  // 3 TABLE
  else if (pageRouteType == PageRouteTypes.tableQrRead) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const HesapApp(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  } else if (pageRouteType == PageRouteTypes.tableTakeTable) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const HesapApp(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  } else if (pageRouteType == PageRouteTypes.tableCreditCard) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const HesapApp(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  }

  // 4 ORDER
  else if (pageRouteType == PageRouteTypes.orderBasket) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const HesapApp(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  } else if (pageRouteType == PageRouteTypes.orderPayment) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const HesapApp(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  } else if (pageRouteType == PageRouteTypes.commonInternetControl) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const HesapApp(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  } else if (pageRouteType == PageRouteTypes.commonProfile) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const HesapApp(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, -1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  } else {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          const HesapApp(), // OUR PAGE to Navigate,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, 1.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
    );
  }
}
