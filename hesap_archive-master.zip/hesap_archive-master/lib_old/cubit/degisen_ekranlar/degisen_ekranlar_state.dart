part of 'degisen_ekranlar_cubit.dart';

class DegisenEkranlarState {
  final int index;

  DegisenEkranlarState({
    this.index = 1,
  });
}
