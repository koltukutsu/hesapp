class HesapUser {
  String id;
  String name;
  String username;
  String email;
  String phone;
  bool anonymous;

  HesapUser({
    required this.id,
    required this.name,
    required this.username,
    required this.email,
    required this.phone,
    required this.anonymous,
  });
}
